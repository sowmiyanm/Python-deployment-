# -*- coding: utf-8 -*-
"""
Created on 2017 Aug

@author: 212589696
"""

from analytics.fault_prediction import fault_prediction
